﻿
Console.WriteLine("Valor da compra: ");
double valorCompra = double.Parse(Console.ReadLine());

Console.WriteLine("Quantidade de parcelas: ");
double parcelas = double.Parse(Console.ReadLine());

if (parcelas <= 1){
    Console.WriteLine("\nValor da compra: R$" + valorCompra);
    Console.WriteLine("Quantidade de parcelas: " + parcelas);
    Console.WriteLine("Desconto: 10%");
    Console.WriteLine("Valor total: R$" + (valorCompra - (valorCompra * 0.1)));
}

else if (parcelas > 2 && parcelas <= 5){
    Console.WriteLine("\nValor da compra: R$" + valorCompra);
    Console.WriteLine("Quantidade de parcelas: " + parcelas);
    Console.WriteLine("Desconto: 0");
    Console.WriteLine("Valor total: R$" + valorCompra);
}

else{
    Console.WriteLine("\nValor da compra: R$" + valorCompra);
    Console.WriteLine("Quantidade de parcelas: " + parcelas);
    Console.WriteLine("Juros: 7%");
    Console.WriteLine("Valor total: R$" + (valorCompra + (valorCompra * 0.07)));
}

Console.ReadLine();

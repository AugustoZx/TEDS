﻿namespace Atv2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            valor = new Label();
            parcelas = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.Font = new Font("Swis721 BlkEx BT", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(290, 181);
            button1.Name = "button1";
            button1.Size = new Size(176, 60);
            button1.TabIndex = 0;
            button1.Text = "CONFIRMAR";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // valor
            // 
            valor.AutoSize = true;
            valor.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            valor.Location = new Point(247, 40);
            valor.Name = "valor";
            valor.Size = new Size(70, 30);
            valor.TabIndex = 1;
            valor.Text = "Valor:";
            valor.Click += label1_Click;
            // 
            // parcelas
            // 
            parcelas.AutoSize = true;
            parcelas.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            parcelas.Location = new Point(247, 107);
            parcelas.Name = "parcelas";
            parcelas.Size = new Size(97, 30);
            parcelas.TabIndex = 2;
            parcelas.Text = "Parcelas:";
            parcelas.Click += parcelas_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(373, 47);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 23);
            textBox1.TabIndex = 3;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(373, 114);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 23);
            textBox2.TabIndex = 4;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(309, 300);
            label1.Name = "label1";
            label1.Size = new Size(117, 30);
            label1.TabIndex = 5;
            label1.Text = "Valor Total";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(parcelas);
            Controls.Add(valor);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label valor;
        private Label parcelas;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label1;
    }
}
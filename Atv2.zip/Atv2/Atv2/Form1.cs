namespace Atv2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void parcelas_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            float valor = Convert.ToSingle(textBox1.Text);
            float parcelas = Convert.ToSingle(textBox2.Text);
            if (parcelas <= 1)
            {
                label1.Text = "Valor total: R$" + (valor - (valor * 0.1));
            }
            else if (parcelas > 1 && parcelas < 5)
            {
                label1.Text = "Valor total: R$" + valor;
            }
            else
            {
                label1.Text = "Valor total: R$" + (valor + (valor * 0.07));
            }
        }
    }
}